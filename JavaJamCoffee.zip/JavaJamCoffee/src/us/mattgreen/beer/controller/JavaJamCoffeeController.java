package us.mattgreen.beer.controller;

import us.mattgreen.beer.model.JavaJamCoffeeModel;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List;
import javax.servlet.RequestDispatcher;

/**
 * This is the main controller for the JavaJam Coffee App.
 * 
 * @author    Textbook, with modifications by Jim Lombardo
 * @version   1.00
 */
public class JavaJamCoffeeController extends HttpServlet {
   private static final String RESULT_PAGE = "result.jsp";

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method. Not currently used.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
    } // </editor-fold>

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html");

        Enum<String> names = request.getParameterNames();

        List<product> result = new ArrayList<>();
        int productCount = 0;
        while (names.hasMoreElements()) {
            productCount++;
            names.nextElement();
        }

        for (int i = 1; i < (productCount / 4) + 1; i++) {
            JavaJamCoffeeModel item = new JavaJamCoffeeModel(
                    Integer.parseInt(request.getParameter("id" + i)),
                    request.getParameter("name" + i),
                    Double.parseDouble(request.getParameter("price" + i))
            );
            if (request.getParameter("quantity" + i) != null) {
                if (isInteger(request.getParameter("quantity" + i))) {
                    item.setQuantity(Integer.parseInt(request.getParameter("quantity" + i)));
                } else {
                    item.setQuantity(0);
                }

            }
            result.add(item);
        }

    }

}
