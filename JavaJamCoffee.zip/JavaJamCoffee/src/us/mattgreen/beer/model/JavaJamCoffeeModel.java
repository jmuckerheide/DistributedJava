package us.mattgreen.beer.model;

import java.util.*;
/*

public class JavaJamCoffeeModel {
    

    public List getBrands(String color) {
        List brands = new ArrayList();
        
        if (color.equals("Iced")) {
             brands.add("Mocha Frappe");
             brands.add("Caramel Frappe");
             
        } else if (color.equals("Hot")) {
            brands.add("Americano");
            brands.add("Black Coffee");
            
        } else {
            brands.add("Nitro infused");
            brands.add("Expresso");
        }

        return brands;
    }
}
*/
package JavaJamCoffeeModel.model;

public class JavaJamCoffeeModel {
    private int ID;
    private String Name;
    private double price;
    private int quantity;

    public JavaJamCoffeeModel(int ID, String name, double price) {
        this.ID = ID;
        this.Name = name;
        this.price = price;
    }


    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {return quantity; }

    public void setQuantity(int quantity) {this.quantity = quantity; }

}
